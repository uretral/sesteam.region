# Change log

## v1.2.9、v1.3.3、v1.4.1

- Add user settings and modify avatar function
- Embedded form support
- Support for customize navigation bar (upper right corner)
- Add scaffolding, database command line tool, web artisan help tool
- Support for customize login page and login logic
- The form supports setting the width and setting the action
- Optimize table filters
- Fix bugs, optimize code and logic